Project Partners:
Mitansh Desai - 101168117
Namish Arora - 101171614

Instructions for server:
Before running the server code, you will have to
install the required modules from NPM. You will have to install required dependencies 
using the command "npm install" in the cmd prompt in the root of the folder.
Then run the server code and access http://localhost:3000/ to navigate the website. 
Once you are on the home page, you can click the embed links to navigate the pages.
