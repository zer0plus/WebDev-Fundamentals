let number_of_rows = 7;
for (i = 1; i <= number_of_rows; i++){
    console.log('#'.repeat(i))
}